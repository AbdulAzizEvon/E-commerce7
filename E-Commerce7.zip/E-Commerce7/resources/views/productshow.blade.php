
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/nav.css') }}" >
    <title>Document</title>
</head>
<body>

{{-- table --}}
<table class="table">
    <thead>
        <tr>
        <th>Product_ID</th>
        <th>Name</th>
        <th>Price</th>
        <th>Description</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
        @php
            $i=1;
        @endphp
       @foreach ($items as  $key=>$row)
          <tr>
            <td>{{ $i++ }}</td>
            <td>{{ $row->title }}</td>
            <td>{{ $row->price }}</td>
            <td>{{ $row->description }}</td>
            <td>
                <div class="imge">
                    <img class="image img-box" src="{{ asset($row->image) }}" alt="Image">
                </div>
            </td>
            <td>
             <button type="submit" class="update-modal">Update</button>
             <button type="submit" class="delete-modal">Delete</button>
        </td>
       </tr>
       @endforeach
    </tbody>
  </table>

</body>
</html>
