<!-- resources/views/cart.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="cart-container">
        <h1>Your Shopping Cart</h1>

        <div class="cart-items">
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart-item" data-id="<?php echo e($item->id); ?>">
                    <img src="<?php echo e(asset('images/' . $item->image)); ?>" alt="<?php echo e($item->name); ?>" class="cart-item-image">
                    <div class="cart-item-details">
                        <h3><?php echo e($item->name); ?></h3>
                        <p><?php echo e($item->description); ?></p>
                        <div class="quantity">
                            <button class="decrease-quantity">-</button>
                            <input type="number" value="<?php echo e($item->quantity); ?>" class="item-quantity" min="1">
                            <button class="increase-quantity">+</button>
                        </div>
                        <p class="item-price">$<?php echo e(number_format($item->price, 2)); ?></p>
                    </div>
                    <button class="remove-item">Remove</button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="cart-summary">
            <p>Total: $<span id="total-price"><?php echo e(number_format($totalPrice, 2)); ?></span></p>
            <button class="checkout-btn">Proceed to Checkout</button>
        </div>
    </div>

    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\E-Commerce7\resources\views\cart.blade.php ENDPATH**/ ?>