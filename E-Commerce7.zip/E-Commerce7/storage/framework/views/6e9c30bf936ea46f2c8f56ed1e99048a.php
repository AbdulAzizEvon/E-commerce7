<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Add Item</h2>
            <form  id="additem"action="<?php echo e(route('store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="items">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div class="item">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" required></textarea>
                </div>
                <div class="items">
                    <label for="price">Price</label>
                    <input type="text" id="price" name="price" required>
                </div>
                <div class="items">
                    <label for="image">File</label>
                    <input type="file" id="image" name="image" required>
                </div>

                <div class="items">
                    <button type="submit" class=" submit">Submit</button>
                </div>
            </form>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\E-Commerce7\resources\views/product.blade.php ENDPATH**/ ?>