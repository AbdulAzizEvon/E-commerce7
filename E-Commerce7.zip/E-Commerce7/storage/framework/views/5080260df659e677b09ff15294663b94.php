
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/nav.css')); ?>" >
    <title>Document</title>
</head>
<body>


<table class="table">
    <thead>
        <tr>
        <th>Product_ID</th>
        <th>Name</th>
        <th>Price</th>
        <th>Description</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
        <?php
            $i=1;
        ?>
       <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($row->title); ?></td>
            <td><?php echo e($row->price); ?></td>
            <td><?php echo e($row->description); ?></td>
            <td>
                <div class="imge">
                    <img class="image img-box" src="<?php echo e(asset($row->image)); ?>" alt="Image">
                </div>
            </td>
            <td>
             <button type="submit" class="update-modal">Update</button>
             <button type="submit" class="delete-modal">Delete</button>
        </td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\E-Commerce7\resources\views/productshow.blade.php ENDPATH**/ ?>