<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Product;


class CartController extends Controller
{
    public function index()
    {
        // Get cart items (example using session)
        $cartItems = session('cart', []);
        $totalPrice = $this->calculateTotalPrice($cartItems);

        return view('cart', compact('cartItems', 'totalPrice'));
    }

    public function addToCart(Request $request, $id)
    {
        // Find product by ID
        $product = Product::findOrFail($id);

        // Add product to session (cart)
        $cart = session('cart', []);
        $cart[$id] = [
            'name' => $product->name,
            'price' => $product->price,
            'quantity' => 1,
            'image' => $product->image,
            'description' => $product->description
        ];
        session(['cart' => $cart]);

        return redirect()->route('cart.index');
    }

    public function removeFromCart($id)
    {
        // Remove product from session
        $cart = session('cart', []);
        unset($cart[$id]);
        session(['cart' => $cart]);

        return redirect()->route('cart.index');
    }

    public function updateQuantity(Request $request, $id)
    {
        // Update quantity in session
        $cart = session('cart', []);
        if (isset($cart[$id])) {
            $cart[$id]['quantity'] = $request->quantity;
            session(['cart' => $cart]);
        }

        return redirect()->route('cart.index');
    }

    private function calculateTotalPrice($cartItems)
    {
        $total = 0;
        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        return $total;
    }
}


