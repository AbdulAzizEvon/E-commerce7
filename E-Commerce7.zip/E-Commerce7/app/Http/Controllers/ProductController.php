<?php

namespace App\Http\Controllers;

use App\Models\Product;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function product(Request $request)
    {
        // $products = Product::all(); // Fetch all products from the database
        return view('product');
    }
    public function store(Request $request){
        //image uplaod
        if($request->image){
            $image = $request->image;
            $imageName = rand().'.'.$image->getClientOriginalName();
            $image->move('upload/', $imageName);
            $imageUrl = 'upload/'.$imageName;
        }
        //data insert
        $item = new Product();

        $item->title = $request->title;
        $item->description = $request->description;
        $item->price = $request->price;
        $item->image = $imageUrl;
        $item->save();
        return back();
    }//end method  	description
    public function productshow(){

        $items = DB::table('products')->orderBy('id','desc')->get();
        // $data = DB::table('products')->get();
        // return $items; exit();
        // dd('items');
        // return view('mystore',compact('items'));
        return view('index',compact('items'));
    }//end method
    public function productshows(){

        $items = DB::table('products')->orderBy('id','desc')->get();
        // $data = DB::table('products')->get();
        // return $items; exit();
        // dd('items');
        // return view('mystore',compact('items'));
        return view('productshow',compact('items'));
    }//end method
}

