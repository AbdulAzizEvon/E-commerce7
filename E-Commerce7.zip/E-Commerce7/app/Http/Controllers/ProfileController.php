<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ProfileController
{
    // Show the profile edit form without extending 'layouts.app'
    public static function edit()
    {
       // $user = Auth::user(); // Get the currently authenticated user
        $user = auth()->user(); // Get the currently authenticated user
        return view('editprofile', compact('user')); // Pass the user data to the view
    }

    // Handle profile update
    public static function update(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . Auth::id(),
            'password' => 'nullable|string|min:8|confirmed',
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Optional avatar update
        ]);

        if ($validator->fails()) {
            return redirect()->route('profile.edit')
                             ->withErrors($validator)
                             ->withInput();
        }

        // Get the currently authenticated user
        $user = Auth::user();

        // Update basic fields
        $user->name = $request->input('name');
        $user->email = $request->input('email');

        // Update password if provided
        if ($request->filled('password')) {
            $user->password = bcrypt($request->input('password'));
        }

        // Handle avatar upload (optional)
        if ($request->hasFile('avatar')) {
            $path = $request->file('avatar')->store('avatars', 'public');
            $user->avatar = $path;
        }

        // Save the user
        $user->save();

        // Redirect with a success message
        return redirect()->route('editprofile')->with('success', 'Profile updated successfully!');
    }
}

