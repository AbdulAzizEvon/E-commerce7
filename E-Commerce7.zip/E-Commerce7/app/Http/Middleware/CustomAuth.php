<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CustomAuth
{
        public function handle($request, Closure $next)
        {
            // Custom logic to authenticate user
            $user = CustomAuthService::authenticate($request);

            if (!$user) {
                return response('Unauthorized', 401);
            }

            Auth::login($user); // Manually log in the user

            return $next($request);
        }

}
