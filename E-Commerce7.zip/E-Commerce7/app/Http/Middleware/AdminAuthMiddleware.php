<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Response;

class AdminAuthMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {

         if(Session::get('email')){
            $email = Session::get('email');
            $user = User::where('email', $email)->first();
            if($user && $user->role=='admin'){
                return $next($request);
                // return redirect()->route('dashboard');
            }
            else{
                return redirect()->route('home');
            }
        }
        else {
         return redirect()->route('login');
         }
    }
}
